module.exports = {
  config: "node_modules/qawolf/js-jest.config.json",
  rootDir: "",
  testTimeout: 60000,
  useTypeScript: false
}
